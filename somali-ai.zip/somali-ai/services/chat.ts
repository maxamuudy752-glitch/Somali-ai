import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { ApiError, MSG } from "@/lib/errors";
import type { SessionUser } from "@/lib/auth";
import { generate, type ChatMsg } from "./ai";

const today = () => new Date().toISOString().slice(0, 10);

// Atomically reserve one generation; returns the new count or throws when over the plan limit.
async function reserveUsage(user: SessionUser) {
  const limit = user.plan === "PRO" ? env.proLimit : env.freeLimit;
  const row = await db.usageDay.upsert({
    where: { userId_day: { userId: user.id, day: today() } },
    create: { userId: user.id, day: today(), count: 1 },
    update: { count: { increment: 1 } },
  });
  if (row.count > limit) {
    await db.usageDay.update({ where: { id: row.id }, data: { count: { decrement: 1 } } });
    throw new ApiError(429, "LIMIT", MSG.limit);
  }
}

async function releaseUsage(userId: string) {
  await db.usageDay.updateMany({ where: { userId, day: today(), count: { gt: 0 } }, data: { count: { decrement: 1 } } }).catch(() => {});
}

const makeTitle = (s: string) => {
  const t = s.replace(/\s+/g, " ").trim();
  return t.length > 48 ? t.slice(0, 48) + "..." : t;
};

export async function sendMessage(opts: {
  user: SessionUser;
  conversationId?: string;
  message: string;
  tool?: string;
  language: string;
  regenerate?: boolean;
}) {
  const { user, message, tool, language, regenerate } = opts;

  let convo = opts.conversationId
    ? await db.conversation.findFirst({ where: { id: opts.conversationId, userId: user.id } }) // ownership check
    : null;
  if (opts.conversationId && !convo) throw new ApiError(404, "NOT_FOUND", MSG.notFound);
  if (!convo) convo = await db.conversation.create({ data: { userId: user.id, title: makeTitle(message) } });

  if (regenerate) {
    // Drop the last assistant reply, reuse the last user message.
    const last = await db.message.findFirst({ where: { conversationId: convo.id }, orderBy: { createdAt: "desc" } });
    if (last?.role === "ASSISTANT") await db.message.delete({ where: { id: last.id } });
  } else {
    await db.message.create({ data: { conversationId: convo.id, role: "USER", content: message } });
  }

  const history = await db.message.findMany({
    where: { conversationId: convo.id },
    orderBy: { createdAt: "asc" },
    take: 40,
  });
  const msgs: ChatMsg[] = history.map((m) => ({ role: m.role === "USER" ? "user" : "assistant", content: m.content }));
  if (!msgs.length || msgs[msgs.length - 1].role !== "user") throw new ApiError(400, "INVALID", MSG.invalid);

  await reserveUsage(user);
  try {
    const out = await generate(msgs, language, tool);
    const [assistant] = await db.$transaction([
      db.message.create({ data: { conversationId: convo.id, role: "ASSISTANT", content: out.text } }),
      db.generation.create({
        data: { userId: user.id, conversationId: convo.id, tool: tool || "chat", prompt: msgs[msgs.length - 1].content, output: out.text, demo: out.demo },
      }),
      db.conversation.update({ where: { id: convo.id }, data: { updatedAt: new Date() } }),
    ]);
    return { conversationId: convo.id, title: convo.title, message: { id: assistant.id, role: "ASSISTANT" as const, content: out.text, createdAt: assistant.createdAt }, demo: out.demo };
  } catch (e) {
    await releaseUsage(user.id); // don't charge for failed generations
    throw e;
  }
}
