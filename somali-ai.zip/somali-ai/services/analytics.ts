import { db } from "@/lib/db";

export async function getStats() {
  const since = new Date(Date.now() - 7 * 86400_000);
  const [users, chats, generations, week, byTool, recentUsers] = await Promise.all([
    db.user.count(),
    db.conversation.count(),
    db.generation.count(),
    db.generation.count({ where: { createdAt: { gte: since } } }),
    db.generation.groupBy({ by: ["tool"], _count: { tool: true }, orderBy: { _count: { tool: "desc" } }, take: 8 }),
    db.user.findMany({
      orderBy: { createdAt: "desc" },
      take: 10,
      select: { id: true, name: true, email: true, plan: true, createdAt: true, _count: { select: { conversations: true, generations: true } } },
    }),
  ]);
  return {
    users, chats, generations, week,
    topTools: byTool.map((t) => ({ tool: t.tool, count: t._count.tool })),
    recentUsers,
  };
}
