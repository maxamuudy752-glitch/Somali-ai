import { env, isDemo } from "@/lib/env";
import { ApiError, MSG } from "@/lib/errors";
import { toolById } from "@/lib/tools";

export type ChatMsg = { role: "user" | "assistant"; content: string };

const BASE_PROMPT = `You are Somali AI, a helpful AI assistant specialized in helping Somali content creators create engaging, clear and natural content.

Core rules:
- Understand Somali (including casual, mixed Somali/English and slang used online) and write natural, fluent Somali the way real Somali creators speak. Avoid stiff, word-for-word translated Somali.
- Preserve the user's meaning. Improve weak ideas instead of just repeating them.
- If something essential is missing (topic, audience, length), ask ONE short question; otherwise just produce the content.
- Keep responses focused. No long introductions or filler.
- Structure scripts clearly with short headings (Hook, Intro, Qaybta 1, Gabagabo, etc.) and make everything actionable and ready to publish.
- Use plain text with light Markdown (## headings, **bold**, - lists). Do not use tables.
- Never invent facts about history, people or statistics. If unsure, say so and suggest the creator verify.`;

const LANG: Record<string, string> = {
  so: "Respond in Somali.",
  en: "Respond in English.",
  mixed: "Respond in natural mixed Somali/English the way Somali creators talk online (Somali sentences with common English creator terms like script, hook, views).",
};

export function buildSystemPrompt(language: string, tool?: string) {
  const t = toolById(tool);
  return [BASE_PROMPT, LANG[language] ?? LANG.so, t ? `Current task: ${t.instruction}` : ""].filter(Boolean).join("\n\n");
}

export type AIResult = { text: string; demo: boolean };

export async function generate(messages: ChatMsg[], language: string, tool?: string): Promise<AIResult> {
  if (isDemo()) return { text: demoResponse(messages, language, tool), demo: true };

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 60_000);
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      signal: ctrl.signal,
      headers: { "content-type": "application/json", "x-api-key": env.aiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: env.aiModel,
        max_tokens: 2000,
        system: buildSystemPrompt(language, tool),
        messages: messages.slice(-20),
      }),
    });
    if (res.status === 429) throw new ApiError(429, "AI_RATE", MSG.rate);
    if (!res.ok) {
      console.error("[ai] provider error", res.status, await res.text().catch(() => ""));
      throw new ApiError(502, "AI_ERROR", MSG.ai);
    }
    const data = await res.json();
    const text = (data.content || []).filter((b: { type: string }) => b.type === "text").map((b: { text: string }) => b.text).join("\n").trim();
    if (!text) throw new ApiError(502, "AI_EMPTY", MSG.ai);
    return { text, demo: false };
  } catch (e) {
    if (e instanceof ApiError) throw e;
    console.error("[ai] network error", e);
    throw new ApiError(504, "AI_NETWORK", MSG.ai);
  } finally {
    clearTimeout(timer);
  }
}

// ---------- DEMO MODE ----------
const BADGE = "🧪 **Demo mode** - jawaabtan waa tusaale. Ku dar `AI_API_KEY` ee `.env` si aad AI dhab ah u hesho.\n\n";

function demoResponse(messages: ChatMsg[], language: string, tool?: string): string {
  const last = messages[messages.length - 1]?.content ?? "";
  const topic = (last.match(/(?:Mawduuca[^:]*|Niche-kaaga|Qoraalkaaga|Qoraalka)[^:]*:\s*(.+)/)?.[1] ?? last.slice(0, 80)).trim();
  const en = language === "en";

  if (tool === "youtube-title" || /cinwaan|title/i.test(last)) {
    return BADGE + `## Cinwaano ku saabsan "${topic}"\n\n1. Runtii ma ogtahay sirta ${topic}? ⭐\n2. 5 Shay oo aadan ogeyn oo ku saabsan ${topic}\n3. ${topic}: Sida ay dhab ahaantii u dhacday\n4. Waxa dadku ka been sheegaan ${topic}\n5. Ka bilow eeg: ${topic} 10 daqiiqo gudahood\n\nKuwa ugu fiican: **#1** iyo **#3**.`;
  }
  if (tool === "tiktok-script" || tool === "shorts-script" || /tiktok|shorts/i.test(last)) {
    return BADGE + `## Script gaaban: ${topic}\n\n**0-3s - Hook**\n"Waxaad rumaysan weyday waxa ku saabsan ${topic}..."\n\n**3-20s - Qaybta 1**\nDaah-fur hal xaqiiqo oo cajiib ah, adigoo isticmaalaya muuqaal degdeg ah.\n\n**20-45s - Qaybta 2**\nUjeedi sababta ay muhiim u tahay dadka daawanaya.\n\n**45-60s - Gabagabo**\n"Haddii aad rabto qeybta 2aad, follow garee!"`;
  }
  if (tool === "youtube-script" || /youtube|script/i.test(last)) {
    return BADGE + `## YouTube Script: ${topic}\n\n### Hook (0:00-0:10)\n"Maxaa dhacay markii... ${topic}? Maanta waxaan kuu sheegayaa sheekada dhabta ah."\n\n### Intro\nSalaan kooban + waxa muuqaalku ka kooban yahay.\n\n### Qaybta 1 - Asalka\nSheeg bilowga iyo xaaladda markaas jirtay.\n\n### Qaybta 2 - Isbeddelka\nQeybta ugu xiisaha badan: dhacdooyinka muhiimka ah.\n\n### Qaybta 3 - Casharka\nWaxa aan ka baran karno maanta.\n\n### Gabagabo\n"Haddii aad ka heshay faa'iido, **subscribe** garee oo kala wadaag asxaabtaada."`;
  }
  if (en) return BADGE + `Here is a sample response for: "${topic}".\n\n- A strong opening line\n- Three clear points\n- A closing call to action`;
  return BADGE + `Waa kuu fahmay: **"${topic}"**.\n\nHalkan waa fikrado degdeg ah:\n\n- **Hook:** Bilow su'aal ama sheeg xaqiiqo yaab leh.\n- **Qaybta ugu muhiimsan:** 3 qodob oo fudud.\n- **Gabagabo:** Dadka weydii inay faallo ka bixiyaan.\n\nMaxaad doonaysaa inaan u beddelo script, caption, ama cinwaan?`;
}
