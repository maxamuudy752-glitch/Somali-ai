"use client";
import { useEffect, useState } from "react";

export function ThemeToggle({ className = "" }: { className?: string }) {
  const [dark, setDark] = useState(false);
  useEffect(() => setDark(document.documentElement.classList.contains("dark")), []);
  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try { localStorage.setItem("theme", next ? "dark" : "light"); } catch {}
  };
  return (
    <button onClick={toggle} aria-label={dark ? "Iftiin" : "Mugdi"} title={dark ? "Habka iftiinka" : "Habka mugdiga"}
      className={`grid h-10 w-10 place-items-center rounded-xl border border-paper-line bg-paper-card text-lg hover:bg-flag-soft dark:border-ink-line dark:bg-ink-soft dark:hover:bg-ink-line ${className}`}>
      {dark ? "☀️" : "🌙"}
    </button>
  );
}
