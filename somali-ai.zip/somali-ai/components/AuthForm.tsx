"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { Logo } from "./Logo";
import { ThemeToggle } from "./ThemeToggle";

export function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const router = useRouter();
  const next = useSearchParams().get("next");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const signup = mode === "signup";

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const f = new FormData(e.currentTarget);
    setBusy(true);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name: f.get("name"), email: f.get("email"), password: f.get("password") }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) { setError(data.error || "Waxbaa khaldamay. Fadlan mar kale isku day."); return; }
      router.replace(next && next.startsWith("/") ? next : "/chat");
      router.refresh();
    } catch {
      setError("Internet-ka waa go'ay. Fadlan hubi isku xirkaaga oo mar kale isku day.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-10">
      <div className="mb-8 flex items-center justify-between"><Logo /><ThemeToggle /></div>
      <h1 className="font-display text-3xl font-extrabold">{signup ? "Samee akoon" : "Ku soo dhawow"}</h1>
      <p className="muted mt-1">{signup ? "Bilow bilaash, kaarka lama rabo." : "Gal si aad ugu soo laabato chat-yadaadii."}</p>
      <form onSubmit={submit} className="mt-6 space-y-3">
        {signup && <input className="input" name="name" placeholder="Magacaaga" autoComplete="name" required maxLength={60} />}
        <input className="input" name="email" type="email" placeholder="Email" autoComplete="email" required />
        <input className="input" name="password" type="password" placeholder="Password (ugu yaraan 8 xaraf)" autoComplete={signup ? "new-password" : "current-password"} required minLength={signup ? 8 : 1} />
        {error && <p role="alert" className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700 dark:bg-red-950 dark:text-red-300">{error}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy ? "Fadlan sug..." : signup ? "Samee akoon" : "Gal"}</button>
      </form>
      <p className="muted mt-6 text-center text-sm">
        {signup ? "Akoon ma leedahay? " : "Akoon ma haysatid? "}
        <Link className="font-semibold text-flag hover:underline" href={signup ? "/login" : "/signup"}>{signup ? "Gal" : "Samee mid cusub"}</Link>
      </p>
    </main>
  );
}
