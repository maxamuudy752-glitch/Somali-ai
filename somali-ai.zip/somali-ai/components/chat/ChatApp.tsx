"use client";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import type { SessionUser } from "@/lib/auth";
import { EXAMPLE_PROMPTS, type Tool } from "@/lib/tools";
import { Logo } from "../Logo";
import { Markdown } from "../Markdown";
import { ThemeToggle } from "../ThemeToggle";
import { SettingsModal } from "./SettingsModal";
import { ToolForm, ToolPicker, ToolsGrid } from "./ToolModal";

type Convo = { id: string; title: string; updatedAt: string };
type Msg = { id: string; role: "USER" | "ASSISTANT"; content: string; demo?: boolean };

const NET_ERR = "Internet-ka waa go'ay. Fadlan hubi isku xirkaaga oo mar kale isku day.";

export default function ChatApp({ initialUser, demo }: { initialUser: SessionUser; demo: boolean }) {
  const router = useRouter();
  const [user, setUser] = useState(initialUser);
  const [convos, setConvos] = useState<Convo[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [sidebar, setSidebar] = useState(false);
  const [picker, setPicker] = useState(false);
  const [tool, setTool] = useState<Tool | null>(null);
  const [settings, setSettings] = useState(false);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const lastTool = useRef<string | undefined>(undefined);

  const loadConvos = useCallback(async () => {
    try {
      const r = await fetch("/api/conversations");
      if (r.status === 401) return router.replace("/login");
      if (r.ok) setConvos((await r.json()).conversations);
    } catch { /* offline: keep what we have */ }
  }, [router]);

  useEffect(() => { loadConvos(); }, [loadConvos]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [messages, loading]);
  useEffect(() => {
    const ta = taRef.current;
    if (ta) { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 180) + "px"; }
  }, [input]);

  async function open(id: string) {
    setSidebar(false); setActiveId(id); setError(""); setMessages([]);
    try {
      const r = await fetch(`/api/conversations/${id}`);
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      setMessages(d.messages);
    } catch (e) { setError((e as Error).message || NET_ERR); }
  }

  function newChat() {
    setActiveId(null); setMessages([]); setError(""); setInput(""); setSidebar(false);
    taRef.current?.focus();
  }

  async function send(message: string, opts: { tool?: string; regenerate?: boolean } = {}) {
    const text = message.trim();
    if (!text) { setError("Fadlan qor fikraddaada marka hore."); return; }
    if (loading) return;
    setError(""); setLoading(true);
    lastTool.current = opts.tool;
    if (!opts.regenerate) {
      setMessages((m) => [...m, { id: "tmp-" + Date.now(), role: "USER", content: text }]);
      setInput("");
    } else {
      setMessages((m) => (m[m.length - 1]?.role === "ASSISTANT" ? m.slice(0, -1) : m));
    }
    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ conversationId: activeId ?? undefined, message: text, tool: opts.tool, language: user.language, regenerate: opts.regenerate }),
      });
      const d = await r.json().catch(() => ({}));
      if (r.status === 401) return router.replace("/login");
      if (!r.ok) throw new Error(d.error || "Waxbaa khaldamay. Fadlan mar kale isku day.");
      setActiveId(d.conversationId);
      setMessages((m) => [...m, { ...d.message, demo: d.demo }]);
      loadConvos();
    } catch (e) {
      setError(e instanceof TypeError ? NET_ERR : (e as Error).message);
    } finally { setLoading(false); }
  }

  function regenerate() {
    const lastUser = [...messages].reverse().find((m) => m.role === "USER");
    if (lastUser) send(lastUser.content, { tool: lastTool.current, regenerate: true });
  }

  async function copy(m: Msg) {
    try { await navigator.clipboard.writeText(m.content); setCopied(m.id); setTimeout(() => setCopied(null), 1500); } catch { setError("Nuqul lama samayn karin."); }
  }

  async function rename(id: string, title: string) {
    setRenaming(null);
    if (!title.trim()) return;
    setConvos((c) => c.map((x) => (x.id === id ? { ...x, title } : x)));
    await fetch(`/api/conversations/${id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ title }) }).catch(() => {});
  }

  async function remove(id: string) {
    if (!confirm("Ma hubtaa inaad tirtirto chat-kan?")) return;
    setConvos((c) => c.filter((x) => x.id !== id));
    if (activeId === id) newChat();
    await fetch(`/api/conversations/${id}`, { method: "DELETE" }).catch(() => {});
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.replace("/"); router.refresh();
  }

  const lastIdx = messages.length - 1;

  return (
    <div className="flex h-[100dvh] overflow-hidden">
      {sidebar && <div className="fixed inset-0 z-30 bg-black/50 md:hidden" onClick={() => setSidebar(false)} />}

      {/* SIDEBAR */}
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-[290px] flex-col border-r border-paper-line bg-paper-card transition-transform dark:border-ink-line dark:bg-ink-soft md:static md:translate-x-0 ${sidebar ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="p-4"><Logo href="/chat" /></div>
        <div className="space-y-2 px-3">
          <button className="btn-primary w-full" onClick={newChat}>＋ Bilow Chat Cusub</button>
          <button className="btn-ghost w-full justify-start" onClick={() => { setPicker(true); setSidebar(false); }}>🧰 Content Tools</button>
        </div>
        <p className="muted mt-5 px-4 text-sm font-semibold">Chat-yadii hore</p>
        <nav className="mt-1 flex-1 space-y-0.5 overflow-y-auto px-2 pb-2" aria-label="Chat history">
          {convos.length === 0 && <p className="muted px-2 py-3 text-sm">Wali chat ma haysatid. Bilow mid cusub!</p>}
          {convos.map((c) => (
            <div key={c.id} className={`group flex items-center rounded-xl pr-1 ${c.id === activeId ? "bg-flag-soft dark:bg-ink-line" : "hover:bg-flag-soft/60 dark:hover:bg-ink-line/60"}`}>
              {renaming === c.id ? (
                <input autoFocus defaultValue={c.title} maxLength={80} className="input m-1 !py-2 text-sm"
                  onBlur={(e) => rename(c.id, e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") rename(c.id, e.currentTarget.value); if (e.key === "Escape") setRenaming(null); }} />
              ) : (
                <>
                  <button onClick={() => open(c.id)} className="min-w-0 flex-1 truncate px-3 py-2.5 text-left text-sm">{c.title}</button>
                  <button onClick={() => setRenaming(c.id)} aria-label="Magac beddel" className="rounded-lg p-1.5 text-xs opacity-60 hover:opacity-100 md:opacity-0 md:group-hover:opacity-100">✏️</button>
                  <button onClick={() => remove(c.id)} aria-label="Tirtir" className="rounded-lg p-1.5 text-xs opacity-60 hover:opacity-100 md:opacity-0 md:group-hover:opacity-100">🗑️</button>
                </>
              )}
            </div>
          ))}
        </nav>
        <div className="space-y-2 border-t border-paper-line p-3 dark:border-ink-line">
          {user.role === "ADMIN" && <a href="/admin" className="btn-ghost w-full justify-start">📊 Admin</a>}
          <button className="btn-ghost w-full justify-start" onClick={() => { setSettings(true); setSidebar(false); }}>⚙️ Settings</button>
          <div className="flex items-center gap-3 px-1 pt-1">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-flag font-bold text-white">{user.name.slice(0, 1).toUpperCase()}</span>
            <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{user.name}</p><p className="muted text-xs">Plan {user.plan}</p></div>
            <button onClick={logout} className="rounded-lg px-2 py-1 text-xs font-semibold text-flag hover:bg-flag-soft dark:hover:bg-ink-line">Ka bax</button>
          </div>
        </div>
      </aside>

      {/* MAIN */}
      <section className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-3 border-b border-paper-line px-3 py-2.5 dark:border-ink-line">
          <button className="grid h-10 w-10 place-items-center rounded-xl border border-paper-line bg-paper-card text-lg dark:border-ink-line dark:bg-ink-soft md:hidden" onClick={() => setSidebar(true)} aria-label="Menu">☰</button>
          <p className="min-w-0 flex-1 truncate font-display font-bold">{convos.find((c) => c.id === activeId)?.title ?? "Chat cusub"}</p>
          {demo && <span className="rounded-full bg-sun/20 px-3 py-1 text-xs font-bold text-amber-700 dark:text-sun">Demo mode</span>}
          <ThemeToggle />
        </header>

        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto w-full max-w-3xl px-4 py-6">
            {messages.length === 0 && !loading ? (
              <div className="pt-6 sm:pt-12">
                <h1 className="font-display text-3xl font-extrabold sm:text-4xl">Maxaan maanta kaa caawin karaa, {user.name.split(" ")[0]}?</h1>
                <p className="muted mt-2">Qor fikraddaada, ama dooro qalab hoose.</p>
                <div className="mt-6 flex flex-wrap gap-2">
                  {EXAMPLE_PROMPTS.map((p) => (
                    <button key={p} onClick={() => { setInput(p); taRef.current?.focus(); }} className="rounded-full border border-paper-line bg-paper-card px-4 py-2 text-left text-sm hover:border-flag dark:border-ink-line dark:bg-ink-soft">{p}</button>
                  ))}
                </div>
                <h2 className="mt-10 mb-3 font-display text-lg font-bold">Maxaad rabtaa inaad abuurto?</h2>
                <ToolsGrid onPick={setTool} />
              </div>
            ) : (
              <ul className="space-y-6">
                {messages.map((m, i) => (
                  <li key={m.id} className={m.role === "USER" ? "flex justify-end" : ""}>
                    {m.role === "USER" ? (
                      <div className="max-w-[88%] whitespace-pre-wrap break-words rounded-2xl rounded-br-md bg-flag px-4 py-3 text-white">{m.content}</div>
                    ) : (
                      <div className="card w-full p-4 sm:p-5">
                        {editing?.id === m.id ? (
                          <>
                            <textarea className="input min-h-[240px] font-mono text-sm" value={editing.text} onChange={(e) => setEditing({ id: m.id, text: e.target.value })} />
                            <div className="mt-3 flex gap-2">
                              <button className="btn-primary !py-2" onClick={() => { setMessages((all) => all.map((x) => (x.id === m.id ? { ...x, content: editing.text } : x))); setEditing(null); }}>Kaydi</button>
                              <button className="btn-ghost !py-2" onClick={() => setEditing(null)}>Jooji</button>
                            </div>
                          </>
                        ) : (
                          <>
                            <Markdown text={m.content} />
                            <div className="mt-4 flex flex-wrap gap-2 border-t border-paper-line pt-3 dark:border-ink-line">
                              <button className="btn-ghost !px-3 !py-1.5" onClick={() => copy(m)}>{copied === m.id ? "✓ La nuqulay" : "📋 Nuqul ka samee"}</button>
                              {i === lastIdx && <button className="btn-ghost !px-3 !py-1.5" onClick={regenerate} disabled={loading}>🔄 Mar kale samee</button>}
                              <button className="btn-ghost !px-3 !py-1.5" onClick={() => setEditing({ id: m.id, text: m.content })}>✏️ Wax ka beddel</button>
                            </div>
                          </>
                        )}
                      </div>
                    )}
                  </li>
                ))}
                {loading && (
                  <li className="card inline-flex items-center gap-1.5 px-4 py-3" aria-live="polite" aria-label="AI wuu qoraayaa">
                    {[0, 1, 2].map((d) => <span key={d} className="h-2 w-2 animate-dot rounded-full bg-flag" style={{ animationDelay: `${d * 0.15}s` }} />)}
                    <span className="muted ml-2 text-sm">AI wuu qoraayaa...</span>
                  </li>
                )}
              </ul>
            )}
            {error && (
              <div role="alert" className="mt-4 flex items-start justify-between gap-3 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700 dark:bg-red-950 dark:text-red-300">
                <span>{error}</span>
                <button onClick={() => setError("")} aria-label="Xir">✕</button>
              </div>
            )}
            <div ref={endRef} />
          </div>
        </div>

        {/* INPUT */}
        <div className="border-t border-paper-line bg-paper px-3 pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] dark:border-ink-line dark:bg-ink">
          <form className="mx-auto flex max-w-3xl items-end gap-2" onSubmit={(e) => { e.preventDefault(); send(input); }}>
            <button type="button" onClick={() => setPicker(true)} className="btn-ghost !h-12 !w-12 shrink-0 !p-0" aria-label="Content Tools">🧰</button>
            <textarea ref={taRef} rows={1} value={input} maxLength={6000} onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && window.matchMedia("(min-width: 768px)").matches) { e.preventDefault(); send(input); } }}
              placeholder="Fikraddaada halkaan ku qor..." className="input max-h-[180px] flex-1 resize-none !py-3" aria-label="Fariinta" />
            <button className="btn-primary !h-12 shrink-0" disabled={loading || !input.trim()}>Dir</button>
          </form>
        </div>
      </section>

      {picker && <ToolPicker onClose={() => setPicker(false)} onPick={(t) => { setPicker(false); setTool(t); }} />}
      {tool && <ToolForm tool={tool} onClose={() => setTool(null)} onSubmit={(msg) => { const id = tool.id; setTool(null); send(msg, { tool: id }); }} />}
      {settings && <SettingsModal user={user} onClose={() => setSettings(false)} onSaved={setUser} />}
    </div>
  );
}
