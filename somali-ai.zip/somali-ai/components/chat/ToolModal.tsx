"use client";
import { useEffect, useState } from "react";
import { buildToolMessage, TOOLS, type Tool } from "@/lib/tools";

export function ToolsGrid({ onPick }: { onPick: (t: Tool) => void }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
      {TOOLS.map((t) => (
        <button key={t.id} onClick={() => onPick(t)} className="card p-4 text-left transition hover:border-flag hover:shadow-md">
          <span className="text-2xl" aria-hidden>{t.icon}</span>
          <p className="mt-2 font-display font-bold leading-tight">{t.title}</p>
          <p className="muted mt-1 text-xs leading-snug">{t.desc}</p>
        </button>
      ))}
    </div>
  );
}

export function ToolPicker({ onPick, onClose }: { onPick: (t: Tool) => void; onClose: () => void }) {
  return (
    <Modal title="Content Tools" onClose={onClose} wide>
      <ToolsGrid onPick={onPick} />
    </Modal>
  );
}

export function ToolForm({ tool, onSubmit, onClose }: { tool: Tool; onSubmit: (message: string) => void; onClose: () => void }) {
  const [values, setValues] = useState<Record<string, string>>(() =>
    Object.fromEntries(tool.fields.filter((f) => f.type === "select").map((f) => [f.name, f.options![0]]))
  );
  const missing = tool.fields.some((f) => f.required && !values[f.name]?.trim());
  return (
    <Modal title={`${tool.icon} ${tool.title}`} onClose={onClose}>
      <form
        className="space-y-4"
        onSubmit={(e) => { e.preventDefault(); if (!missing) onSubmit(buildToolMessage(tool, values)); }}
      >
        {tool.fields.map((f) => (
          <label key={f.name} className="block">
            <span className="mb-1.5 block text-sm font-semibold">{f.label}{f.required && " *"}</span>
            {f.type === "select" ? (
              <select className="input" value={values[f.name]} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })}>
                {f.options!.map((o) => <option key={o}>{o}</option>)}
              </select>
            ) : f.type === "textarea" ? (
              <textarea className="input min-h-[110px]" maxLength={4000} placeholder={f.placeholder} value={values[f.name] || ""} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} />
            ) : (
              <input className="input" maxLength={300} placeholder={f.placeholder} value={values[f.name] || ""} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} />
            )}
          </label>
        ))}
        <button className="btn-primary w-full" disabled={missing}>Samee {tool.title}</button>
      </form>
    </Modal>
  );
}

export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 grid items-end bg-black/50 sm:place-items-center" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title}
        className={`card max-h-[92vh] w-full animate-pop overflow-y-auto rounded-b-none p-5 sm:rounded-b-2xl sm:p-6 ${wide ? "sm:max-w-3xl" : "sm:max-w-lg"}`}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-extrabold">{title}</h2>
          <button onClick={onClose} aria-label="Xir" className="grid h-9 w-9 place-items-center rounded-lg hover:bg-flag-soft dark:hover:bg-ink-line">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
