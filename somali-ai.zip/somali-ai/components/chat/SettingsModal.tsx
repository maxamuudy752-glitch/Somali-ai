"use client";
import { useState } from "react";
import type { SessionUser } from "@/lib/auth";
import { ThemeToggle } from "../ThemeToggle";
import { Modal } from "./ToolModal";

const LANGS = [
  { v: "so", l: "Soomaali" },
  { v: "en", l: "English" },
  { v: "mixed", l: "Soomaali + English" },
];

export function SettingsModal({ user, onSaved, onClose }: { user: SessionUser; onSaved: (u: SessionUser) => void; onClose: () => void }) {
  const [name, setName] = useState(user.name);
  const [language, setLanguage] = useState(user.language);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  async function save() {
    setBusy(true); setMsg("");
    try {
      const res = await fetch("/api/auth/me", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ name, language }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      onSaved(data.user); setMsg("La kaydiyay ✓");
    } catch (e) {
      setMsg((e as Error).message || "Waxbaa khaldamay. Fadlan mar kale isku day.");
    } finally { setBusy(false); }
  }

  return (
    <Modal title="Settings" onClose={onClose}>
      <div className="space-y-5">
        <label className="block">
          <span className="mb-1.5 block text-sm font-semibold">Magacaaga</span>
          <input className="input" value={name} maxLength={60} onChange={(e) => setName(e.target.value)} />
        </label>
        <div>
          <span className="mb-1.5 block text-sm font-semibold">Luqadda jawaabaha AI</span>
          <div className="grid grid-cols-3 gap-2">
            {LANGS.map((o) => (
              <button key={o.v} type="button" onClick={() => setLanguage(o.v)}
                className={`rounded-xl border px-2 py-3 text-sm font-semibold transition ${language === o.v ? "border-flag bg-flag-soft text-flag-deep dark:bg-ink-line dark:text-white" : "border-paper-line dark:border-ink-line"}`}>
                {o.l}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm font-semibold">Iftiin / Mugdi</span><ThemeToggle />
        </div>
        <div className="muted text-sm">{user.email} · Plan: <b>{user.plan}</b></div>
        <div className="flex items-center gap-3">
          <button className="btn-primary" onClick={save} disabled={busy || !name.trim()}>Kaydi</button>
          {msg && <span className="muted text-sm">{msg}</span>}
        </div>
      </div>
    </Modal>
  );
}
