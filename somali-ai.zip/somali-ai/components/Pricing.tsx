import Link from "next/link";

const PLANS = [
  {
    name: "FREE", price: "$0", note: "Bilaash weligeed", cta: "Bilow Bilaash", href: "/signup", featured: false,
    items: ["15 generations maalintii", "Qalabka content ee aasaasiga ah", "Chat history", "Soomaali, English, iyo isku-dhafan"],
  },
  {
    name: "PRO", price: "$9", note: "bishii (dhawaan)", cta: "Isku day Pro", href: "/signup", featured: true,
    items: ["300 generations maalintii", "Dhammaan qalabka content-ka", "Scripts ka dheer", "AI mudnaan leh (priority)", "Chat history aad u badan"],
  },
];

// Payments are not wired yet: add Stripe/Paddle checkout behind the Pro button later
// and flip User.plan to PRO from the webhook.
export function Pricing() {
  return (
    <div className="mx-auto grid max-w-3xl gap-4 sm:grid-cols-2">
      {PLANS.map((p) => (
        <div key={p.name} className={`card flex flex-col p-6 ${p.featured ? "border-flag ring-2 ring-flag/30" : ""}`}>
          <p className="font-display text-lg font-bold">{p.name}</p>
          <p className="mt-2 font-display text-4xl font-extrabold">{p.price}</p>
          <p className="muted text-sm">{p.note}</p>
          <ul className="mt-5 flex-1 space-y-2 text-sm">
            {p.items.map((i) => <li key={i} className="flex gap-2"><span className="text-flag">✓</span>{i}</li>)}
          </ul>
          <Link href={p.href} className={`mt-6 ${p.featured ? "btn-primary" : "btn-ghost"}`}>{p.cta}</Link>
        </div>
      ))}
    </div>
  );
}
