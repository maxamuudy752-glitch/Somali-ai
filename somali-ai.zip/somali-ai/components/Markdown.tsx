import { Fragment } from "react";

function inline(text: string) {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((p, i) => {
    if (p.startsWith("**") && p.endsWith("**")) return <strong key={i}>{p.slice(2, -2)}</strong>;
    if (p.startsWith("`") && p.endsWith("`")) return <code key={i} className="rounded bg-flag-soft px-1 py-0.5 text-[0.9em] dark:bg-ink-line">{p.slice(1, -1)}</code>;
    return <Fragment key={i}>{p}</Fragment>;
  });
}

export function Markdown({ text }: { text: string }) {
  const lines = text.split("\n");
  const out: React.ReactNode[] = [];
  let list: string[] = [];
  const flush = (k: number) => {
    if (list.length) {
      out.push(<ul key={`l${k}`} className="my-2 list-disc space-y-1 pl-5">{list.map((li, i) => <li key={i}>{inline(li)}</li>)}</ul>);
      list = [];
    }
  };
  lines.forEach((raw, i) => {
    const line = raw.trimEnd();
    const li = line.match(/^\s*(?:[-*•]|\d+\.)\s+(.*)/);
    if (li) { list.push(li[1]); return; }
    flush(i);
    const h = line.match(/^(#{1,4})\s+(.*)/);
    if (h) out.push(<p key={i} className={`mt-4 mb-1 font-display font-bold ${h[1].length <= 2 ? "text-lg" : "text-base"}`}>{inline(h[2])}</p>);
    else if (line.trim() === "") out.push(<div key={i} className="h-2" />);
    else out.push(<p key={i} className="leading-relaxed">{inline(line)}</p>);
  });
  flush(lines.length);
  return <div className="break-words">{out}</div>;
}
