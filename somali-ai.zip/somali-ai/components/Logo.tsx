import Link from "next/link";

export function Star({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path fill="currentColor" d="M12 2.2l2.9 6.9 7.4.6-5.6 4.8 1.7 7.2L12 17.8 5.6 21.7l1.7-7.2L1.7 9.7l7.4-.6z" />
    </svg>
  );
}

export function Logo({ href = "/", size = 36 }: { href?: string; size?: number }) {
  return (
    <Link href={href} className="inline-flex items-center gap-2.5" aria-label="Somali AI">
      <span className="grid place-items-center rounded-xl bg-flag text-white" style={{ width: size, height: size }}>
        <Star className="h-[55%] w-[55%]" />
      </span>
      <span className="font-display text-xl font-extrabold tracking-tight">Somali AI</span>
    </Link>
  );
}
