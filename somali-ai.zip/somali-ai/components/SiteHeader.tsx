import Link from "next/link";
import { Logo } from "./Logo";
import { ThemeToggle } from "./ThemeToggle";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-20 border-b border-paper-line bg-paper/85 backdrop-blur dark:border-ink-line dark:bg-ink/85">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
        <Logo />
        <nav className="ml-6 hidden gap-6 text-sm font-semibold md:flex">
          <Link href="/#qalabka" className="hover:text-flag">Qalabka</Link>
          <Link href="/#sida" className="hover:text-flag">Sida uu u shaqeeyo</Link>
          <Link href="/pricing" className="hover:text-flag">Qiimaha</Link>
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <ThemeToggle />
          <Link href="/login" className="btn-ghost hidden !py-2.5 sm:inline-flex">Gal</Link>
          <Link href="/signup" className="btn-primary !py-2.5">Bilow Hadda</Link>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-paper-line dark:border-ink-line">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-10 sm:flex-row sm:items-center sm:justify-between">
        <div><Logo /><p className="muted mt-2 text-sm">Fikradaada u beddel Content.</p></div>
        <nav className="flex gap-5 text-sm font-semibold">
          <Link href="/pricing">Qiimaha</Link><Link href="/login">Gal</Link><Link href="/signup">Samee akoon</Link>
        </nav>
        <p className="muted text-sm">© {new Date().getFullYear()} Somali AI</p>
      </div>
    </footer>
  );
}
