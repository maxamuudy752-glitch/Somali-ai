import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  const email = (process.env.ADMIN_EMAILS || "admin@example.com").split(",")[0].trim().toLowerCase();
  const passwordHash = await bcrypt.hash("ChangeMe123!", 12);
  await db.user.upsert({
    where: { email },
    update: { role: "ADMIN" },
    create: { email, name: "Admin", passwordHash, role: "ADMIN", plan: "PRO" },
  });
  console.log(`Admin ready: ${email} / ChangeMe123!  (change this password)`);
}

main().finally(() => db.$disconnect());
