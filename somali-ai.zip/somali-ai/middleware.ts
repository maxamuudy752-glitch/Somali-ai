import { NextResponse, type NextRequest } from "next/server";
import { COOKIE, verifyToken } from "@/lib/session";

// Fast gate only (cookie signature). Real authorization happens in route handlers / server components.
export async function middleware(req: NextRequest) {
  const token = req.cookies.get(COOKIE)?.value;
  const uid = token ? await verifyToken(token) : null;
  if (!uid) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("next", req.nextUrl.pathname);
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = { matcher: ["/chat/:path*", "/admin/:path*"] };
