import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        flag: { DEFAULT: "#4189DD", deep: "#2B6BBF", soft: "#E6F0FC" },
        sun: "#F2B632",
        ink: { DEFAULT: "#0E1B2C", soft: "#16263A", line: "#223652" },
        paper: { DEFAULT: "#F5F8FC", card: "#FFFFFF", line: "#DCE5F0" },
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      keyframes: {
        dot: { "0%,80%,100%": { opacity: ".25", transform: "translateY(0)" }, "40%": { opacity: "1", transform: "translateY(-3px)" } },
        pop: { from: { opacity: "0", transform: "scale(.97) translateY(6px)" }, to: { opacity: "1", transform: "none" } },
      },
      animation: { dot: "dot 1.2s infinite ease-in-out", pop: "pop .18s ease-out" },
    },
  },
  plugins: [],
};
export default config;
