import { notFound, redirect } from "next/navigation";
import Link from "next/link";
import { Logo } from "@/components/Logo";
import { getUser } from "@/lib/auth";
import { getStats } from "@/services/analytics";
import { TOOLS } from "@/lib/tools";

export const metadata = { title: "Admin - Somali AI" };
export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getUser();
  if (!user) redirect("/login?next=/admin");
  if (user.role !== "ADMIN") notFound(); // hide the route from non-admins
  const s = await getStats();
  const name = (id: string) => TOOLS.find((t) => t.id === id)?.title ?? (id === "chat" ? "Chat caadi ah" : id);
  const max = Math.max(1, ...s.topTools.map((t) => t.count));

  return (
    <main className="mx-auto max-w-5xl px-4 py-6">
      <div className="mb-8 flex items-center justify-between"><Logo href="/chat" /><Link href="/chat" className="btn-ghost">← Chat</Link></div>
      <h1 className="font-display text-3xl font-extrabold">Admin dashboard</h1>
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {[["Isticmaalayaal", s.users], ["Chat-yo", s.chats], ["Generations", s.generations], ["7-ta maalmood", s.week]].map(([l, v]) => (
          <div key={l as string} className="card p-5"><p className="muted text-sm">{l}</p><p className="mt-1 font-display text-3xl font-extrabold">{v}</p></div>
        ))}
      </div>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <section className="card p-5">
          <h2 className="font-display text-lg font-bold">Qalabka ugu isticmaalka badan</h2>
          <ul className="mt-4 space-y-3">
            {s.topTools.length === 0 && <li className="muted text-sm">Wali xog ma jirto.</li>}
            {s.topTools.map((t) => (
              <li key={t.tool}>
                <div className="flex justify-between text-sm"><span>{name(t.tool)}</span><b>{t.count}</b></div>
                <div className="mt-1 h-2 rounded-full bg-flag-soft dark:bg-ink-line"><div className="h-2 rounded-full bg-flag" style={{ width: `${(t.count / max) * 100}%` }} /></div>
              </li>
            ))}
          </ul>
        </section>
        <section className="card overflow-x-auto p-5">
          <h2 className="font-display text-lg font-bold">Isticmaalayaasha cusub</h2>
          <table className="mt-3 w-full text-left text-sm">
            <thead className="muted"><tr><th className="pb-2">Magac</th><th>Plan</th><th>Chat</th><th>Gen</th></tr></thead>
            <tbody>
              {s.recentUsers.map((u) => (
                <tr key={u.id} className="border-t border-paper-line dark:border-ink-line">
                  <td className="py-2"><p className="font-semibold">{u.name}</p><p className="muted text-xs">{u.email}</p></td>
                  <td>{u.plan}</td><td>{u._count.conversations}</td><td>{u._count.generations}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
    </main>
  );
}
