import Link from "next/link";
import { Pricing } from "@/components/Pricing";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";
import { Star } from "@/components/Logo";
import { TOOLS } from "@/lib/tools";

const FEATURES = [
  { t: "Somali-first", d: "Waxaa loo dhisay Soomaaliyeed. Wuxuu qoraa Soomaali dabiici ah, ma aha turjumaad qallafsan." },
  { t: "Degdeg ah", d: "Ka bilow fikrad ku saabsan hal jumlad ilaa script buuxa daqiiqado gudahood." },
  { t: "Mobile-ka ku habboon", d: "Wuxuu si fiican ugu shaqeeyaa taleefankaaga, xitaa internet gaabis ah." },
  { t: "Wax ka beddel oo nuqul ka samee", d: "Script kasta wax ka beddel, mar kale samee, ama nuqul ka samee hal gujin." },
];

const STEPS = [
  { t: "Qor fikraddaada", d: "Ku qor Soomaali, English, ama labadaba." },
  { t: "Dooro qalab", d: "YouTube, TikTok, caption, hook ama cinwaan." },
  { t: "Publish garee", d: "Nuqul ka samee content-ka diyaarka ah oo soo dhig." },
];

export default function Home() {
  return (
    <>
      <SiteHeader />
      <main>
        {/* HERO */}
        <section className="relative overflow-hidden">
          <Star className="pointer-events-none absolute -right-24 -top-16 h-[420px] w-[420px] text-flag/10 dark:text-flag/15" />
          <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-4 py-14 lg:grid-cols-[1.1fr_1fr] lg:py-24">
            <div>
              <h1 className="font-display text-5xl font-extrabold leading-[1.02] tracking-tight sm:text-6xl lg:text-7xl">
                Hal fikrad.<br />Content dhamaystiran.
              </h1>
              <p className="muted mt-6 max-w-xl text-lg leading-relaxed">
                Somali AI wuxuu kaa caawinayaa inaad fikradahaaga u beddesho scripts, captions, hooks iyo content diyaar u ah in la publish gareeyo.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/signup" className="btn-primary !px-7 !py-3.5 text-base">Bilow Bilaash</Link>
                <Link href="/chat" className="btn-ghost !px-7 !py-3.5 text-base">Isku day AI</Link>
              </div>
              <p className="muted mt-4 text-sm">Kaarka lama rabo. Waxaa u shaqeeya taleefan kasta.</p>
            </div>

            {/* Example conversation */}
            <div className="card p-4 shadow-xl shadow-flag/10 sm:p-5" aria-label="Tusaale wada-hadal">
              <div className="flex justify-end">
                <p className="max-w-[90%] rounded-2xl rounded-br-md bg-flag px-4 py-3 text-white">Waxaan rabaa video YouTube ah oo ka hadlaya taariikhda Soomaaliya.</p>
              </div>
              <div className="mt-3 rounded-2xl rounded-bl-md bg-paper p-4 text-sm leading-relaxed dark:bg-ink">
                <p className="font-display font-bold">Hook (0:00-0:10)</p>
                <p className="mt-1">&ldquo;Ma ogtahay in Soomaaliya ay mar ahayd udubdhexaadka ganacsiga Badweynta Hindiya?&rdquo;</p>
                <p className="mt-3 font-display font-bold">Qaybaha muuqaalka</p>
                <ul className="mt-1 list-disc space-y-1 pl-5">
                  <li>Dawladihii hore iyo dekedaha</li>
                  <li>Xornimada iyo dhisidda dalka</li>
                  <li>Maanta iyo mustaqbalka</li>
                </ul>
                <p className="mt-3">Ma rabtaa inaan qoro script buuxa oo 8 daqiiqo ah?</p>
              </div>
              <div className="mt-3 flex gap-2">
                <span className="rounded-full border border-paper-line px-3 py-1 text-xs dark:border-ink-line">📋 Nuqul ka samee</span>
                <span className="rounded-full border border-paper-line px-3 py-1 text-xs dark:border-ink-line">🔄 Mar kale samee</span>
              </div>
            </div>
          </div>
        </section>

        {/* FEATURES */}
        <section className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="max-w-2xl font-display text-3xl font-extrabold sm:text-4xl">Content qurux badan, hal fikrad oo kaliya.</h2>
          <div className="mt-10 grid gap-4 sm:grid-cols-2">
            {FEATURES.map((f) => (
              <div key={f.t} className="card p-6"><h3 className="font-display text-xl font-bold">{f.t}</h3><p className="muted mt-2 leading-relaxed">{f.d}</p></div>
            ))}
          </div>
        </section>

        {/* TOOLS */}
        <section id="qalabka" className="bg-flag-soft/60 py-16 dark:bg-ink-soft/50">
          <div className="mx-auto max-w-6xl px-4">
            <h2 className="font-display text-3xl font-extrabold sm:text-4xl">Content Tools</h2>
            <p className="muted mt-2 max-w-xl">12 qalab oo loogu talagalay abuurayaasha Soomaaliyeed.</p>
            <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
              {TOOLS.map((t) => (
                <Link key={t.id} href="/chat" className="card p-4 transition hover:border-flag hover:shadow-md">
                  <span className="text-2xl" aria-hidden>{t.icon}</span>
                  <p className="mt-2 font-display font-bold leading-tight">{t.title}</p>
                  <p className="muted mt-1 text-xs leading-snug">{t.desc}</p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* HOW */}
        <section id="sida" className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="font-display text-3xl font-extrabold sm:text-4xl">Sida uu u shaqeeyo</h2>
          <ol className="mt-10 grid gap-4 md:grid-cols-3">
            {STEPS.map((s, i) => (
              <li key={s.t} className="card p-6">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-flag font-display font-bold text-white">{i + 1}</span>
                <h3 className="mt-4 font-display text-xl font-bold">{s.t}</h3>
                <p className="muted mt-1">{s.d}</p>
              </li>
            ))}
          </ol>
        </section>

        {/* PRICING */}
        <section className="mx-auto max-w-6xl px-4 pb-20">
          <h2 className="text-center font-display text-3xl font-extrabold sm:text-4xl">Ka bilow bilaash</h2>
          <div className="mt-10"><Pricing /></div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
