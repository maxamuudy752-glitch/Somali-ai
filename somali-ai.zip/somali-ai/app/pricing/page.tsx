import { Pricing } from "@/components/Pricing";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";

export const metadata = { title: "Qiimaha - Somali AI" };

export default function PricingPage() {
  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-16">
        <h1 className="text-center font-display text-4xl font-extrabold sm:text-5xl">Qiime fudud, bilow bilaash</h1>
        <p className="muted mx-auto mt-3 max-w-xl text-center">Ka bilow Free. Marka aad u baahato wax dheeri ah, u gudub Pro.</p>
        <div className="mt-12"><Pricing /></div>
      </main>
      <SiteFooter />
    </>
  );
}
