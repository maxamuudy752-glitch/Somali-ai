import type { Metadata, Viewport } from "next";
import { Bricolage_Grotesque, Figtree } from "next/font/google";
import "./globals.css";

const display = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-display", display: "swap" });
const body = Figtree({ subsets: ["latin"], variable: "--font-body", display: "swap" });

export const metadata: Metadata = {
  title: "Somali AI - Fikradaada u beddel Content",
  icons: { icon: "/favicon.svg" },
  description: "Somali AI wuxuu kaa caawinayaa inaad fikradahaaga u beddesho scripts, captions, hooks iyo content diyaar u ah in la publish gareeyo.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#4189DD" };

// Runs before paint so there is no light/dark flash.
const themeScript = `try{var t=localStorage.getItem("theme");if(t==="dark"||(!t&&matchMedia("(prefers-color-scheme: dark)").matches))document.documentElement.classList.add("dark")}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="so" suppressHydrationWarning className={`${display.variable} ${body.variable}`}>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body>{children}</body>
    </html>
  );
}
