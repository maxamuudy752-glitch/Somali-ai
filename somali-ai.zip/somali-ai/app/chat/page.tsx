import { redirect } from "next/navigation";
import ChatApp from "@/components/chat/ChatApp";
import { getUser } from "@/lib/auth";
import { isDemo } from "@/lib/env";

export const metadata = { title: "Chat - Somali AI" };
export const dynamic = "force-dynamic";

export default async function ChatPage() {
  const user = await getUser();
  if (!user) redirect("/login?next=/chat");
  return <ChatApp initialUser={user} demo={isDemo()} />;
}
