import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { handleError } from "@/lib/errors";
import { getStats } from "@/services/analytics";

export async function GET() {
  try {
    await requireAdmin();
    return NextResponse.json(await getStats());
  } catch (e) {
    return handleError(e);
  }
}
