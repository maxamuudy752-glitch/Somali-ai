import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleError } from "@/lib/errors";

export async function GET() {
  try {
    const user = await requireUser();
    const conversations = await db.conversation.findMany({
      where: { userId: user.id },
      orderBy: { updatedAt: "desc" },
      take: 100,
      select: { id: true, title: true, createdAt: true, updatedAt: true },
    });
    return NextResponse.json({ conversations });
  } catch (e) {
    return handleError(e);
  }
}

export async function POST() {
  try {
    const user = await requireUser();
    const c = await db.conversation.create({ data: { userId: user.id }, select: { id: true, title: true, createdAt: true, updatedAt: true } });
    return NextResponse.json({ conversation: c });
  } catch (e) {
    return handleError(e);
  }
}
