import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { ApiError, MSG, handleError } from "@/lib/errors";
import { renameSchema } from "@/lib/validation";

type Ctx = { params: { id: string } };

async function owned(id: string, userId: string) {
  const c = await db.conversation.findFirst({ where: { id, userId } });
  if (!c) throw new ApiError(404, "NOT_FOUND", MSG.notFound);
  return c;
}

export async function GET(_: Request, { params }: Ctx) {
  try {
    const user = await requireUser();
    await owned(params.id, user.id);
    const messages = await db.message.findMany({
      where: { conversationId: params.id },
      orderBy: { createdAt: "asc" },
      select: { id: true, role: true, content: true, createdAt: true },
    });
    return NextResponse.json({ messages });
  } catch (e) {
    return handleError(e);
  }
}

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const user = await requireUser();
    await owned(params.id, user.id);
    const { title } = renameSchema.parse(await req.json());
    const c = await db.conversation.update({ where: { id: params.id }, data: { title }, select: { id: true, title: true, updatedAt: true } });
    return NextResponse.json({ conversation: c });
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(_: Request, { params }: Ctx) {
  try {
    const user = await requireUser();
    await owned(params.id, user.id);
    await db.conversation.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}
