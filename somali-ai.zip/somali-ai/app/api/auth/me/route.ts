import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleError } from "@/lib/errors";
import { settingsSchema } from "@/lib/validation";

export async function GET() {
  try {
    return NextResponse.json({ user: await requireUser() });
  } catch (e) {
    return handleError(e);
  }
}

// Profile / settings update (name, language).
export async function PATCH(req: Request) {
  try {
    const me = await requireUser();
    const data = settingsSchema.parse(await req.json());
    const user = await db.user.update({
      where: { id: me.id },
      data,
      select: { id: true, email: true, name: true, role: true, plan: true, language: true },
    });
    return NextResponse.json({ user });
  } catch (e) {
    return handleError(e);
  }
}
