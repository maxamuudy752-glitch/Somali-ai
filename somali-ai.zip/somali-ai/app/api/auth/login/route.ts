import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { ApiError, MSG, handleError } from "@/lib/errors";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { cookieOptions, COOKIE, signToken } from "@/lib/session";
import { loginSchema } from "@/lib/validation";

// Constant-ish timing: compare against a throwaway hash when the email is unknown.
const DUMMY = bcrypt.hashSync("not-a-real-password", 12);

export async function POST(req: Request) {
  try {
    if (!rateLimit(`login:${clientIp(req)}`, 10, 60_000 * 10)) throw new ApiError(429, "RATE", MSG.rate);
    const { email, password } = loginSchema.parse(await req.json());
    const user = await db.user.findUnique({ where: { email } });
    const ok = await bcrypt.compare(password, user?.passwordHash ?? DUMMY);
    if (!user || !ok) throw new ApiError(401, "BAD_LOGIN", MSG.badLogin);
    const res = NextResponse.json({ ok: true });
    res.cookies.set(COOKIE, await signToken(user.id), cookieOptions);
    return res;
  } catch (e) {
    return handleError(e);
  }
}
