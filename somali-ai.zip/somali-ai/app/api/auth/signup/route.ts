import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { ApiError, MSG, handleError } from "@/lib/errors";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { cookieOptions, COOKIE, signToken } from "@/lib/session";
import { signupSchema } from "@/lib/validation";

export async function POST(req: Request) {
  try {
    if (!rateLimit(`signup:${clientIp(req)}`, 5, 60_000 * 10)) throw new ApiError(429, "RATE", MSG.rate);
    const data = signupSchema.parse(await req.json());
    if (await db.user.findUnique({ where: { email: data.email } })) throw new ApiError(409, "EMAIL", MSG.emailTaken);
    const user = await db.user.create({
      data: {
        name: data.name,
        email: data.email,
        passwordHash: await bcrypt.hash(data.password, 12),
        role: env.adminEmails.includes(data.email) ? "ADMIN" : "USER",
      },
    });
    const res = NextResponse.json({ ok: true });
    res.cookies.set(COOKIE, await signToken(user.id), cookieOptions);
    return res;
  } catch (e) {
    return handleError(e);
  }
}
