import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { ApiError, MSG, handleError } from "@/lib/errors";
import { rateLimit } from "@/lib/rate-limit";
import { toolById } from "@/lib/tools";
import { chatSchema } from "@/lib/validation";
import { sendMessage } from "@/services/chat";

export const maxDuration = 60;

export async function POST(req: Request) {
  try {
    const user = await requireUser();
    if (!rateLimit(`chat:${user.id}`, 20, 60_000)) throw new ApiError(429, "RATE", MSG.rate);

    let body: unknown;
    try {
      body = await req.json();
    } catch {
      throw new ApiError(400, "INVALID", MSG.invalid);
    }
    const raw = body as { message?: unknown };
    if (typeof raw?.message !== "string" || !raw.message.trim()) throw new ApiError(400, "EMPTY", MSG.empty);

    const data = chatSchema.parse(body);
    if (data.tool && !toolById(data.tool)) throw new ApiError(400, "INVALID", MSG.invalid);

    const result = await sendMessage({ user, ...data });
    return NextResponse.json(result);
  } catch (e) {
    return handleError(e);
  }
}
