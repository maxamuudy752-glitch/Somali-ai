# Somali AI - Fikradaada u beddel Content

Somali-first AI assistant for Somali content creators (YouTube, TikTok, Facebook, Instagram scripts, hooks, titles, captions and more).

**Stack:** Next.js 14 (App Router) · TypeScript · Tailwind CSS · PostgreSQL · Prisma · JWT cookie auth (jose + bcrypt) · Anthropic API.

## 1. Install

Requirements: Node.js 18.18+ and PostgreSQL 14+ (or Docker).

```bash
npm install
cp .env.example .env
```

## 2. Environment variables (`.env`)

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `AUTH_SECRET` | Session signing secret. Generate: `openssl rand -base64 32` |
| `AI_API_KEY` | Anthropic API key. **Leave empty for DEMO mode** |
| `AI_MODEL` | Model name (default `claude-sonnet-4-5`) |
| `ADMIN_EMAILS` | Comma-separated emails that become ADMIN when they sign up |
| `FREE_DAILY_GENERATIONS` / `PRO_DAILY_GENERATIONS` | Daily limits per plan |

## 3. Database

Quick local Postgres with Docker:

```bash
docker compose up -d
```

Then create the tables:

```bash
npx prisma db push          # quick start
# or: npx prisma migrate dev --name init   (recommended for production history)
npm run db:seed             # optional: creates the admin from ADMIN_EMAILS (password: ChangeMe123!)
```

## 4. Run

```bash
npm run dev
```

Open http://localhost:3000. Sign up, then go to `/chat`. Without `AI_API_KEY` the app runs in **demo mode** (a badge is shown and answers are labelled).

To use real AI, set `AI_API_KEY` in `.env` and restart.

## 5. Admin

Sign up with an email listed in `ADMIN_EMAILS` (or run the seed), then open `/admin`.
Non-admins get a 404 on that route and 403 on `/api/admin/*`.

## 6. Deploy (Vercel + Neon/Supabase)

1. Create a Postgres database (Neon, Supabase, Railway...). Copy its connection string.
2. Push this repo to GitHub and import it in Vercel.
3. Add env vars in Vercel: `DATABASE_URL`, `AUTH_SECRET`, `AI_API_KEY`, `ADMIN_EMAILS`.
4. Run the schema once against production: `DATABASE_URL="..." npx prisma migrate deploy` (or `db push`).
5. Deploy. The build script runs `prisma generate` automatically.

Any Node host works too (`npm run build && npm start`), including Docker on a VPS.

## Architecture

```
app/            routes: landing, /chat, /login, /signup, /pricing, /admin, /api/*
components/     UI (chat/ has the chat app, modals, tools)
lib/            env, db client, session/auth, validation (zod), rate-limit, errors, tool definitions
services/       ai.ts (prompt, provider call, demo mode) · chat.ts (conversations, limits) · analytics.ts
prisma/         schema.prisma (User, Conversation, Message, Generation, UsageDay), seed.ts
```

## Security notes

- API key only used server-side; user IDs always come from the signed httpOnly cookie, never the request body.
- Every conversation query is scoped by `userId` (ownership check) so private history stays private.
- Inputs validated with zod and stripped of control characters; output is rendered by React (no raw HTML).
- Rate limits: in-memory per-IP for auth, per-user for chat, plus daily plan limits in the DB.
  For multiple server instances replace `lib/rate-limit.ts` with Redis/Upstash.

## Next steps

- Streaming responses (SSE) for faster perceived speed
- Payments: add Stripe/Paddle checkout on the Pro button, set `User.plan` from the webhook
- Email verification and password reset
- Save generated content to a "Library" view (data already stored in `Generation`)
