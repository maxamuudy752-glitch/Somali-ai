// Content tool definitions. Shared by the UI (forms) and the server (prompt building).
export type ToolField = {
  name: string;
  label: string;
  placeholder?: string;
  type?: "text" | "textarea" | "select";
  options?: string[];
  required?: boolean;
};

export type Tool = {
  id: string;
  title: string;
  desc: string;
  icon: string; // emoji keeps the bundle small
  instruction: string; // sent to the model in addition to the system prompt
  fields: ToolField[];
};

const TONE: ToolField = { name: "tone", label: "Hab-qoraalka", type: "select", options: ["Xiiso leh", "Professional", "Qosol", "Dareen leh", "Fudud oo cad"] };
const AUDIENCE: ToolField = { name: "audience", label: "Dadka lagu beegay", placeholder: "Tusaale: dhalinyarada Soomaaliyeed" };

export const TOOLS: Tool[] = [
  {
    id: "youtube-script", title: "YouTube Script", icon: "▶️", desc: "Script buuxa oo hook, qaybo iyo gabagabo leh.",
    instruction: "Write a complete YouTube video script with: Hook (first 10 seconds), Intro, main sections with clear headings, and an outro with a call to action. Mark spoken lines clearly and suggest B-roll in [brackets].",
    fields: [
      { name: "topic", label: "Mawduuca", placeholder: "Tusaale: Taariikhda Soomaaliya", required: true },
      { name: "length", label: "Dhererka muuqaalka", type: "select", options: ["3 daqiiqo", "5 daqiiqo", "8 daqiiqo", "10+ daqiiqo"] },
      TONE, AUDIENCE,
    ],
  },
  {
    id: "tiktok-script", title: "TikTok Script", icon: "🎵", desc: "Script gaaban oo 15-60 ilbiriqsi ah.",
    instruction: "Write a TikTok script with timestamps (e.g. 0-3s), on-screen text, and spoken lines. Keep it punchy and fast.",
    fields: [{ name: "topic", label: "Mawduuca", required: true }, { name: "length", label: "Dhererka", type: "select", options: ["15 ilbiriqsi", "30 ilbiriqsi", "60 ilbiriqsi"] }, TONE, AUDIENCE],
  },
  {
    id: "youtube-title", title: "YouTube Title", icon: "🏷️", desc: "Cinwaano xooggan oo dadka riixaya.",
    instruction: "Give 10 YouTube title options, mixed styles (curiosity, number, how-to, emotional). Keep each under 70 characters. Mark the 2 best.",
    fields: [{ name: "topic", label: "Mawduuca muuqaalka", required: true }, AUDIENCE],
  },
  {
    id: "video-hook", title: "Video Hook", icon: "🎣", desc: "Bilow dadka soo jiita 3-ka ilbiriqsi ee ugu horreeya.",
    instruction: "Write 6 different video hooks (first 3-5 seconds), each a different angle: question, bold claim, story, shock, problem, promise.",
    fields: [{ name: "topic", label: "Mawduuca", required: true }, { name: "platform", label: "Platform", type: "select", options: ["YouTube", "TikTok", "Instagram Reels", "Facebook"] }, TONE],
  },
  {
    id: "video-description", title: "Video Description", icon: "📝", desc: "Sharaxaad iyo hashtags diyaar ah.",
    instruction: "Write a YouTube video description: 2-line hook, summary, timestamps placeholder, call to action, and 8-12 relevant hashtags.",
    fields: [{ name: "topic", label: "Waxa muuqaalku ku saabsan yahay", type: "textarea", required: true }, TONE],
  },
  {
    id: "thumbnail-idea", title: "Thumbnail Idea", icon: "🖼️", desc: "Fikrado sawir iyo qoraal thumbnail ah.",
    instruction: "Give 5 thumbnail concepts. For each: main visual, facial expression/pose, 2-4 word overlay text, and color suggestion.",
    fields: [{ name: "topic", label: "Mawduuca muuqaalka", required: true }, { name: "title", label: "Cinwaanka (haddii aad haysato)" }],
  },
  {
    id: "facebook-post", title: "Facebook Post", icon: "📘", desc: "Qoraal Facebook oo la wadaagi karo.",
    instruction: "Write a Facebook post with a strong opening line, short paragraphs, and a closing question to drive comments. Offer 2 variations.",
    fields: [{ name: "topic", label: "Mawduuca", type: "textarea", required: true }, TONE, AUDIENCE],
  },
  {
    id: "instagram-caption", title: "Instagram Caption", icon: "📸", desc: "Caption gaaban iyo hashtags.",
    instruction: "Write 4 Instagram caption options of different lengths with emojis used sparingly, and a set of 10 hashtags.",
    fields: [{ name: "topic", label: "Sawirka/muuqaalka waa maxay?", type: "textarea", required: true }, TONE],
  },
  {
    id: "shorts-script", title: "Shorts Script", icon: "⚡", desc: "YouTube Shorts oo ka yar 60 ilbiriqsi.",
    instruction: "Write a YouTube Shorts script under 60 seconds with a looping ending idea. Include timestamps and on-screen text.",
    fields: [{ name: "topic", label: "Mawduuca", required: true }, TONE, AUDIENCE],
  },
  {
    id: "content-ideas", title: "Content Ideas", icon: "💡", desc: "10 fikradood oo cusub oo aad samayn karto.",
    instruction: "Give 10 specific content ideas (not generic), each with a one-line angle and the best format (YouTube, TikTok, post).",
    fields: [{ name: "niche", label: "Niche-kaaga", placeholder: "Tusaale: cunto, ganacsi, ciyaaraha", required: true }, AUDIENCE],
  },
  {
    id: "rewrite", title: "Rewrite Content", icon: "✨", desc: "Qoraalkaaga ka dhig mid wanaagsan.",
    instruction: "Rewrite the user's text so it is clearer, more engaging and more natural, preserving the meaning. Then list 3 short notes on what you changed.",
    fields: [{ name: "text", label: "Qoraalkaaga", type: "textarea", required: true }, { name: "style", label: "Hab", type: "select", options: ["Professional", "Xiiso leh", "Ka gaaban", "Fudud"] }],
  },
  {
    id: "translate", title: "Somali ↔ English", icon: "🌍", desc: "Turjum dabiici ah, ma ahan eray-ka-eray.",
    instruction: "Translate between Somali and English naturally (detect the source language). Preserve meaning and tone. Give the main translation first, then one alternative if useful.",
    fields: [{ name: "text", label: "Qoraalka", type: "textarea", required: true }, { name: "direction", label: "Jihada", type: "select", options: ["Auto", "Somali → English", "English → Somali"] }],
  },
];

export const toolById = (id?: string) => TOOLS.find((t) => t.id === id);

// Compose the user-visible message from a filled tool form.
export function buildToolMessage(tool: Tool, values: Record<string, string>): string {
  const lines = tool.fields
    .map((f) => (values[f.name]?.trim() ? `${f.label}: ${values[f.name].trim()}` : ""))
    .filter(Boolean);
  return `${tool.title}\n${lines.join("\n")}`;
}

export const EXAMPLE_PROMPTS = [
  "Samee 60-second TikTok script oo ku saabsan ganacsiga yar yar",
  "I sii 10 YouTube ideas oo ku saabsan cuntada Soomaaliyeed",
  "Cinwaan xooggan ii samee muuqaal ku saabsan taariikhda Muqdisho",
  "Qoraalkan ka dhig mid professional ah",
  "Samee hook dadka soo jiita",
];
