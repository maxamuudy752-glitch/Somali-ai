import { cookies } from "next/headers";
import { db } from "./db";
import { ApiError, MSG } from "./errors";
import { COOKIE, verifyToken } from "./session";

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  role: "USER" | "ADMIN";
  plan: "FREE" | "PRO";
  language: string;
};

// The user ID always comes from the signed cookie, never from the client body.
export async function getUser(): Promise<SessionUser | null> {
  const token = cookies().get(COOKIE)?.value;
  if (!token) return null;
  const id = await verifyToken(token);
  if (!id) return null;
  return db.user.findUnique({
    where: { id },
    select: { id: true, email: true, name: true, role: true, plan: true, language: true },
  });
}

export async function requireUser(): Promise<SessionUser> {
  const u = await getUser();
  if (!u) throw new ApiError(401, "UNAUTH", MSG.unauth);
  return u;
}

export async function requireAdmin(): Promise<SessionUser> {
  const u = await requireUser();
  if (u.role !== "ADMIN") throw new ApiError(403, "FORBIDDEN", MSG.forbidden);
  return u;
}
