import { NextResponse } from "next/server";
import { ZodError } from "zod";

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
  }
}

// Friendly Somali messages shown directly to users.
export const MSG = {
  generic: "Waxbaa khaldamay. Fadlan mar kale isku day.",
  empty: "Fadlan qor fikraddaada marka hore.",
  unauth: "Fadlan gal akoonkaaga si aad u sii wadato.",
  forbidden: "Ma haysatid fasax aad ku gasho bogan.",
  rate: "Aad bay u dheereysay. Fadlan sug daqiiqad oo mar kale isku day.",
  limit: "Waxaad gaartay xadka maanta. La soco berri ama u gudub Pro.",
  ai: "AI-ga hadda ma jawaabi karo. Fadlan mar kale isku day.",
  db: "Xogta lama gaari karo hadda. Fadlan mar kale isku day.",
  badLogin: "Email-ka ama password-ka waa khalad.",
  emailTaken: "Email-kan horey ayaa loo isticmaalay.",
  notFound: "Lama helin.",
  invalid: "Xogta aad gelisay ma saxna. Fadlan dib u eeg.",
};

export function handleError(e: unknown) {
  if (e instanceof ApiError) {
    return NextResponse.json({ error: e.message, code: e.code }, { status: e.status });
  }
  if (e instanceof ZodError) {
    return NextResponse.json({ error: MSG.invalid, code: "INVALID" }, { status: 400 });
  }
  console.error("[api]", e);
  const prismaLike = typeof e === "object" && e !== null && "clientVersion" in e;
  return NextResponse.json(
    { error: prismaLike ? MSG.db : MSG.generic, code: prismaLike ? "DB" : "INTERNAL" },
    { status: 500 }
  );
}
