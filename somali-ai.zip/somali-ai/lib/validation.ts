import { z } from "zod";

// Strip control chars and trim. React escapes output, so we never render raw HTML.
const clean = (s: string) => s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim();
const text = (max: number) => z.string().transform(clean).pipe(z.string().min(1).max(max));

export const signupSchema = z.object({
  name: text(60),
  email: z.string().trim().toLowerCase().email().max(120),
  password: z.string().min(8).max(100),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(120),
  password: z.string().min(1).max(100),
});

export const chatSchema = z.object({
  conversationId: z.string().cuid().optional(),
  message: text(6000),
  tool: z.string().max(40).optional(),
  language: z.enum(["so", "en", "mixed"]).default("so"),
  regenerate: z.boolean().optional(),
});

export const renameSchema = z.object({ title: text(80) });
export const settingsSchema = z.object({
  name: text(60).optional(),
  language: z.enum(["so", "en", "mixed"]).optional(),
});
