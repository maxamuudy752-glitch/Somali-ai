export const env = {
  aiKey: process.env.AI_API_KEY || "",
  aiModel: process.env.AI_MODEL || "claude-sonnet-4-5",
  adminEmails: (process.env.ADMIN_EMAILS || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean),
  freeLimit: Number(process.env.FREE_DAILY_GENERATIONS || 15),
  proLimit: Number(process.env.PRO_DAILY_GENERATIONS || 300),
};
export const isDemo = () => !env.aiKey;
